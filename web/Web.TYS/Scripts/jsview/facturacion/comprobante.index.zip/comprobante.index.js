var grilla = $("#gridcomprobantes");
var pagergrilla = $("#gridcomprobantespager");
var editOptionsNew = {
    keys: true,
    successfunc: function () {
        var $self = $(this);
        setTimeout(function () {
            $self.trigger("reloadGrid");
        }, 50);
    }
};

$(document).ready(function () {

    configchosen();
    configurarGrilla();
    configurarBotones();
});
function configurarBotones() {
    $("#btnBuscar").click(function (event) {
        reload();
    });

    $("#btnGenerar").click(function (event) {
        alert('generar')
        var selIds = $(grilla).jqGrid('getGridParam', 'selarrrow');
        if (selIds.length > 1)
            messagebox('No puede continuar.', 'Debe seleccionar solo un elemento.', 'warning')
        else {
            GenerarComprobante(selIds)
        }
    });
    $("#btnGenerarNota").click(function (event) {
        alert('generar')
        var selIds = $(grilla).jqGrid('getGridParam', 'selarrrow');
        if (selIds == '')
            messagebox('No puede continuar.', 'Debe seleccionar al menos un elemento.', 'warning');
        else if (selIds.length > 1)
            messagebox('No puede continuar.', 'Debe seleccionar solo un elemento.', 'warning')
        else
            generarNC(selIds);
    });

    //
    $("#btnAnularPreliquidacion").click(function (event) {
        var selIds = $(grilla).jqGrid('getGridParam', 'selarrrow');

        if (selIds == '')
            messagebox('No puede continuar.', 'Debe seleccionar al menos un elemento.', 'warning');
        else if (selIds.length > 1)
            messagebox('No puede continuar.', 'Debe seleccionar solo un elemento.', 'warning')
        else
            AnularPreliquidacion(selIds);
    });

    $("#btnEditarComprobante").click(function (event) {
        var selIds = $(grilla).jqGrid('getGridParam', 'selarrrow');
        if (selIds == '')
            messagebox('No puede continuar.', 'Debe seleccionar al menos un elemento.', 'warning');
        else if (selIds.length > 1)
            messagebox('No puede continuar.', 'Debe seleccionar solo un elemento.', 'warning')
        else
            editarcomprobante(selIds);
    });

    $("#btnEditarComprobante2").click(function (event) {
        var url = UrlHelper.Action("ValidarComprobante2", "Facturacion", "Facturacion");

        var selIds = $(grilla).jqGrid('getGridParam', 'selarrrow');
        if (selIds == '')
            messagebox('No puede continuar.', 'Debe seleccionar al menos un elemento.', 'warning');
        else if (selIds.length > 1)
            messagebox('No puede continuar.', 'Debe seleccionar solo un elemento.', 'warning')
        else {
            $.ajax({
                url: url,
                type: 'POST',
                dataType: 'json',
                data: { "idcomprobante": String(selIds) }
            })
            .done(function (data) {
                if (data.idcomprobante == 0) {
                    editarcomprobante2(selIds);
                }
                else {
                    messagebox('No puede continuar.', 'Ya se ha generado un comprobante.', 'warning')
                }
            })
            .fail(function () {
                console.log("error");
            });
        }
    });


    $("#btnEliminarComprobante").click(function (event) {
        var selIds = $(grilla).jqGrid('getGridParam', 'selarrrow');
        if (selIds == '')
            messagebox('No puede continuar.', 'Debe seleccionar al menos un elemento.', 'warning');
        else if (selIds.length > 1)
            messagebox('No puede continuar.', 'Debe seleccionar solo un elemento.', 'warning')
        else
            eliminarcomprobante(selIds);
    });

    $("#btnAnularComprobante").click(function (event) {
        var selIds = $(grilla).jqGrid('getGridParam', 'selarrrow');
        if (selIds == '')
            messagebox('No puede continuar.', 'Debe seleccionar al menos un elemento.', 'warning');
        else if (selIds.length > 1)
            messagebox('No puede continuar.', 'Debe seleccionar solo un elemento.', 'warning')
        else
            anularcomprobante(selIds);
    });
}

function GenerarComprobante(items) {
    var url = UrlHelper.Action("GenerarComprobante", "Facturacion", "Facturacion");
    var url2 = UrlHelper.Action("JsonGenerarComprobante", "Facturacion", "Facturacion");
    $.get(url, function (data) {
        $("#modalcontent").html(data);
        $("#modalcontainer").modal("show");

        $("#idpreliquidacion").val(items);

        $("#btnGenFactura").click(function (event) {
            $.ajax({
                url: url2,
                type: 'POST',
                dataType: 'json',
                data: { "idpreliquidacion": $("#idpreliquidacion").val(), "tipocomprobante": "FACT" }
            })
            .done(function () {
                $("#modalcontainer").modal("hide");
                reload();
            })
            .fail(function () {
                console.log("error");
            })
        });
        $("#btnGenBoleta").click(function (event) {
            $.ajax({
                url: url2,
                type: 'POST',
                dataType: 'json',
                data: { "idpreliquidacion": $("#idpreliquidacion").val(), "tipocomprobante": "BOL" }
            })
            .done(function () {
                $("#modalcontainer").modal("hide");
                reload();
            })
            .fail(function () {
                console.log("error");
            })
        });
    });
}
function configchosen() {
    var config = {
        '.chosen-select': {
            max_selected_options: 5,
            allow_single_deselect: false,
            no_results_text: 'Oops, no se encontró el ubigeo!'
        }
    }
    for (var selector in config) {
        $(selector).chosen(config[selector]);
    }
}
function editarcomprobante2(idcomprobante) {
    var url = UrlHelper.Action("EditarFactura", "Facturacion", "Facturacion") + "?idcomprobante=" + idcomprobante;
    var url2 = UrlHelper.Action("JsonEditarComprobante", "Facturacion", "Facturacion");

    $.get(url, function (data) {
        $("#modalcontentL").html(data);
        $("#modalcontainerL").modal('show');


        $("#addrow").click(function () {
            $("#griddetallefactura").jqGrid('addRowData', 0, 1, "last");
            $("#griddetallefactura").editRow(0, true);
        });


        configurarGrillaDetalle()

        $("#btnEditFactura").click(function (event) {
            $.ajax({
                url: url2,
                type: 'POST',
                dataType: 'json',
                data: {
                    idcomprobante: $("#idcomprobante").val()
                    , subtotal: $("#strsubtotal").val()
                    , igv: $("#strigv").val()
                }
            })
            .done(function (data) {
                if (data.res) {
                    var id = data.idcomprobante;
                    $("#modalcontainerL").modal("hide");
                    reload();
                }
                else {
                    swal("No puede continuar", data.msj, "warning");
                }
            })
            .fail(function () {
                console.log("error");
            })
        });
       
    });
}
function editarcomprobante(idpreliquidacion) {
    var url = UrlHelper.Action("PreFactura", "Facturacion", "Facturacion") + "?idpreliquidacion=" + idpreliquidacion;
    var url2 = UrlHelper.Action("JsonGenerarComprobante", "Facturacion", "Facturacion");
    $.get(url, function (data) {
        $("#modalcontentL").html(data);
        $("#modalcontainerL").modal('show');

        $("#txtdescripcion").val($("#descripcion").val());
        $("#btnGenFactura").click(function (event) {

            url2 = url2 + "?idcomprobantepago=" + $("#idcomprobantepago").val()
            + "&subtotal=" + $("#strsubtotal").val()
            + "&igv=" + $("#strigv").val()
            + "&__descripcion=" + $("#txtdescripcion").val()

            alert(url2)

            $.ajax({
                url: url2,
                type: 'POST',
                dataType: 'json',
                data: {}
            })
            .done(function (data) {
                var id = data.idcomprobante;
                $("#modalcontainerL").modal("hide");
                reload();
                var url = "http://104.36.166.65/webreports/factura.aspx?idcomprobante=" + String(id) + "&valorigv=" + data.valorigv;
                window.open(url);
            })
            .fail(function () {
                console.log("error");
            })
        });
        $(".editor").jqte({
        });
    });
}
function generarNC(idcomprobante) {
    var url = UrlHelper.Action("PreNotaCredito", "Facturacion", "Facturacion") + "?idcomprobantepago=" + idcomprobante;
    var url2 = UrlHelper.Action("JsonGenerarNotaCredito", "Facturacion", "Facturacion");
    $.get(url, function (data) {
        $("#modalcontentL").html(data);
        $("#modalcontainerL").modal('show');
        $("#txtdescripcion").val($("#descripcion").val());

        $("#strsubtotal").blur(function (event) {
            if ($("#strsubtotal").val() == '') return;
            calcularigvtotal();
        });

        $("#addrow").click(function () {
            $("#griddetallefactura").jqGrid('addRowData', 0, 1, "last");
            $("#griddetallefactura").editRow(0, true);
        });



        configurarGrillaDetalle()

        $("#btnGenNC").click(function (event) {
            var id = $("#idpreliquidacion").val();
            url2 = url2 + "?idpreliquidacion=" + $("#idpreliquidacion").val()
            + "&subtotal=" + $("#strsubtotal").val()
            + "&idcomprobantepago=" + idcomprobante
            + "&igv=" + $("#strigv").val()
            + "&__descripcion=" + $("#txtdescripcion").val()

            $.ajax({
                url: url2,
                type: 'POST',
                dataType: 'json',
                data: {}
            })
            .done(function (data) {
                var id = data.idcomprobante;
                $("#modalcontainerL").modal("hide");
                reload();
                //var url = "http://104.36.166.65/webreports/factura.aspx?idcomprobante=" + String(id) + "&valorigv=" + data.valorigv;
               // window.open(url);
            })
            .fail(function () {
                console.log("error");
            })
        });
        $(".editor").jqte({
        });
    });
}

function calcularigvtotal() {
    //var igv = 0.18;
    $("#strigv").val((parseFloat($("#strsubtotal").val()) * igv).toFixed(2));
    $("#strtotal").val((parseFloat($("#strsubtotal").val()) + parseFloat($("#strigv").val())).toFixed(2));
}
function eliminarcomprobante(idcomprobante) {
    var url = UrlHelper.Action("JsonEliminarComprobante", "Facturacion", "Facturacion") + "?idcomprobante=" + idcomprobante;

    swal({
        title: "Eliminar Comprobante",
        text: "¿Está seguro que desea eliminar la preliquidación?",
        type: "warning",
        showCancelButton: true,
        cancelButtonText: "Cancelar",
        confirmButtonColor: '#DD6B55',
        confirmButtonText: 'Eliminar',
        closeOnConfirm: true,
        closeOnCancel: true
    },
       function (isConfirm) {
           if (isConfirm) {
               $.ajax({
                   url: url,
                   type: 'POST',
                   dataType: 'json',
                   data: {}
               })
               .done(function () {
                   reload();
                   messagebox('Registro Exitoso', 'Se ha anulado el comprobante.', 'success');
               })
               .fail(function () {
                   messagebox('No se pudo generar', 'No se pudo anular el comprobante', 'error');
               })
           }
       });
}

function anularcomprobante(idcomprobante) {
    var url = UrlHelper.Action("JsonAnularComprobante", "Facturacion", "Facturacion") + "?idcomprobante=" + idcomprobante;

    swal({
        title: "Anular Comprobante",
        text: "¿Está seguro que desea anular el comprobante?",
        type: "warning",
        showCancelButton: true,
        cancelButtonText: "Cancelar",
        confirmButtonColor: '#DD6B55',
        confirmButtonText: 'Anular',
        closeOnConfirm: true,
        closeOnCancel: true
    },
       function (isConfirm) {
           if (isConfirm) {
               $.ajax({
                   url: url,
                   type: 'POST',
                   dataType: 'json',
                   data: {}
               })
               .done(function () {
                   reload();
                   messagebox('Registro Exitoso', 'Se ha anulado el comprobante.', 'success');
               })
               .fail(function () {
                   messagebox('No se pudo generar', 'No se pudo anular el comprobante', 'error');
               })
           }
       });
}