﻿
namespace Web.TYS.Models.Account
{
    public class ForgotPasswordModel
    {
        public string Email { get; set; }
    }
}