
$(document).ready(function () {


    const url = UrlHelper.Action("MonitoreoEntregaFluvial", "Monitoreo", "Monitoreo")
    window.open(url, "Gestión de entrega fluvial    ", 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=yes, copyhistory=no, width=1400px, height=650px, top=top, left=left');

});